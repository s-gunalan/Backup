'''
Created on May 19, 2017

@author: 265332
'''
import httplib2
import requests
from pip._vendor.requests.auth import HTTPBasicAuth



if __name__ == '__main__':

    httplib2.debuglevel = 0
    http = httplib2.Http()
    
    content_type_header = "application/vnd.com.nsn.cumulocity.measurementCollection+json"
    content_accept = "application/vnd.com.nsn.cumulocity.measurementCollection+json"
    content_username = "ravi.evani@cognizant.com"
    content_pwd = "Srirama@1"
    content_auth = content_username, content_pwd

    
    url = "https://cognizant.iot.softwareag.com/measurement/measurements?source=96960"

    data = {
        "time" : "2017-09-06T12:03:27.845+02:00",
        "type" : "com_cumulocity_model_DoorSensorEvent",
        "text" : "Door sensor was triggered.",
        "source": { "id" : "16501"}
}

    headers = {'Content-Type': content_type_header, 'Accept': content_accept}
    print ("Posting %s" % data)
    content = requests.get(url,headers,auth=HTTPBasicAuth(content_username,content_pwd))
    print(content.text)
