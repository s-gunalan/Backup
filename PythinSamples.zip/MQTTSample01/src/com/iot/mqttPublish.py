'''
Created on May 18, 2017

@author: 250571
'''
import time;
import mqttConnect,getConfig

Channel = getConfig.getConfigVal("Channel")
client = mqttConnect.getMQTTCon("ID")
count = 0
while (count < 9):
    #sensor_data = [read_temp(), read_humidity(), read_pressure()]
    client.publish(Channel, "Welcome")
    time.sleep(1*60)
    count = count+1


