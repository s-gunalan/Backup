'''
Created on May 18, 2017

@author: 250571
'''

import time
import paho.mqtt.client as mqtt
import getConfig

def getMQTTCon(clientId):
    ClientHost = getConfig.getConfigVal("ClientHost")
    client = mqtt.Client(clientId)
    client.connect(ClientHost, 60883, 60)
    client.on_connect = on_connect
    client.loop_start()
    return client
    

def on_connect(client, userdata, flags, rc):
    print("Connected with result code "+str(rc))
    

