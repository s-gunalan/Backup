'''
Created on May 18, 2017

@author: 250571
'''
import time;
import mqttConnect,getConfig

def on_message(client, userdata, msg):
    message = str(msg.payload)
    print(msg.topic+" "+message)
    
Channel = getConfig.getConfigVal("Channel")
client = mqttConnect.getMQTTCon("ID")
client.subscribe(Channel)
client.on_message = on_message

count = 0
while (count < 9):
    time.sleep(1*60)
    count = count+1


