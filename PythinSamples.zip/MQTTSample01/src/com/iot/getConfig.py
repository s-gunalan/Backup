'''
Created on May 18, 2017

@author: 250571
'''
import ConfigParser
from functools import partial
from itertools import chain
class Helper:
    def __init__(self, section, file):
        
        self.readline = partial(next, chain(("[{0}]\n".format(section),), file, ("",)))
config = ConfigParser.RawConfigParser(allow_no_value=True)

def getConfigVal(var):
    with open("E:\\MQTTConfig.cfg") as ifh:
        config.readfp(Helper("Broker", ifh))
        print(config.get("Broker", var))
        return config.get("Broker", var)