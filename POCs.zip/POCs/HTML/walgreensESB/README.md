# walgreensESB

Webpage for displaying server inventory for 2L ESB team
